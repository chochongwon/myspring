package com.test.spring.controller;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import com.test.spring.service.Board1Service;
import com.test.spring.vo.Board1VO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class Board1Controller {
	
	private static final Logger logger = LoggerFactory.getLogger(Board1Controller.class);
	
	@Resource(name = "board1Service")
	private Board1Service board1Service;
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/selectListBoard1", method = RequestMethod.GET)
	@Transactional
	public ModelAndView selectListBoard1(Locale locale, Model model) throws Exception {
		logger.info("Welcome selectListBoard1! The client locale is {}.", locale);
		
		ModelAndView view = new ModelAndView(); // view 객체
		view.setViewName("selectListBoard1"); // 이동할 jsp 이름

		List<Board1VO> list = board1Service.selectListBoard1();
		view.addObject("list", list ); // jsp 로 넘길 데이터

		return view;
	}	
	
}
