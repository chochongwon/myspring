package com.test.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.spring.service.Board1Service;
import com.test.spring.dao.Board1DAO;

@Service("board1Service")
public class Board1ServiceImpl implements Board1Service {
	
	@Autowired
	private Board1DAO board1Dao;
	
	@Override
	@Transactional
	public List selectListBoard1() throws Exception {
		return board1Dao.selectListBoard1();
	}

}
