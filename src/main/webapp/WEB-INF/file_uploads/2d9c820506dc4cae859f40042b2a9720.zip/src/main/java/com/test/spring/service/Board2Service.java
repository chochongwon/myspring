package com.test.spring.service;

import java.util.ArrayList;

import com.test.spring.vo.Board2VO;

public interface Board2Service {
    Board2VO selectOneBoard2();
    
    public ArrayList<Board2VO> selectListBoard2();	
}
