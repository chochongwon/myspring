package com.test.spring.dao;

import java.util.List;

import com.test.spring.vo.Board2VO;

public interface Board2DAO {
	
    Board2VO selectOneBoard2();

	List selectListBoard2();
}
