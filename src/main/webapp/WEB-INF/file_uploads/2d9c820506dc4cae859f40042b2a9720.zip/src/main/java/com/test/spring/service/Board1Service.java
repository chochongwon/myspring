package com.test.spring.service;

import java.util.List;
import com.test.spring.vo.Board1VO;

public interface Board1Service {
	List selectListBoard1() throws Exception;
}
