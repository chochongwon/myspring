package com.test.spring.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/home.do", method = RequestMethod.GET)
	public ModelAndView home(Locale locale, Model model) throws Exception {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		ModelAndView view = new ModelAndView(); // view 객체
		view.setViewName("home"); // 이동할 jsp 이름
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);		
		String formattedDate = dateFormat.format(date);		
		view.addObject("serverTime", formattedDate ); // jsp 로 넘길 데이터
		
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession();
		
		HttpServletRequest request = attr.getRequest();
		
		String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
		String cPath = request.getContextPath();
		String sPath = request.getServletPath();
		
		String nodeId = System.getProperty("jboss.server.name");
		String hostName = System.getProperty("java.rmi.server.hostname");
		
		String variableString = (String)session.getAttribute("SESSION_TEST_VARIABLE");
		int count = 0;
		if(variableString != null)
		{
			count = Integer.parseInt(variableString);
			count++;
		}
		session.setAttribute("SESSION_TEST_VARIABLE", String.valueOf(count));
				
		view.addObject("basePath", basePath);
		view.addObject("cPath", cPath);
		view.addObject("sPath", sPath);		
		view.addObject("sessionId", session.getId() );
		view.addObject("session", session);
		view.addObject("nodeId", nodeId);
		view.addObject("hostName", hostName);
		view.addObject("count", count);
		
		return view;
	}	
}